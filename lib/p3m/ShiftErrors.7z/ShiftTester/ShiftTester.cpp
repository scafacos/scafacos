/* 
 * File:   TriclinicParticleDuplication.cpp
 * Author: Gabriel Sichardt
 *
 * Created on May 6, 2014, 9:34 PM
 */

#include <mpi.h>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <list>
#include <random>
#include <fcs.h>
#include <assert.h>

using namespace std;

#define CHARGE -0.11
#define CHARGE2 -0.11

fcs_float boxa[3]={10.0,0.0,0.0};fcs_float boxb[3]={0.0,10.0,0.0};fcs_float boxc[3]={0.0,0.0,10.0};
fcs_float bbox = 10.0;
fcs_float sum_charges = 0.0;


    fcs_int number=30000;
    fcs_float alpha = 10.0;
    std::list<fcs_float> cutoffs= {10,0.5,0.3,0.2,0.175,0.165,0.135,0.1,0.095,0.09,0.085,0.08,0.075,0.07,0.065,0.06,0.055,0.05,0.045,0.04};
    
class Particle {
public:
    fcs_float position[3];
    fcs_float charge;
    fcs_float potential[40];
    fcs_float field[40][3];
    fcs_float rcut[40];
   
    fcs_float dis[3];
    fcs_float offset[40];
    Particle() {
    };

    Particle(fcs_float boxa[3], fcs_float boxb[3], fcs_float boxc[3], fcs_float sum_charges, int size) {
       //this->potential = static_cast<double*>(malloc(2*cutoffs.size()*sizeof(fcs_float)));
        //this->field
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<int> dis(1, 9999);
   
        for (int i = 0; i < 3; i++) {         
            this->position[i] = dis(gen)/1000.0;
            for(int j = 0;j<12;j++) {
                this->field[j][i] = 0.0;
                this->potential[j]=0.0;
                this->offset[j]=0.0;
            }     
        }        
        
        this->charge = (sum_charges != 0.0) ? -sum_charges : ((size%4==0)?-CHARGE:-CHARGE2);
       // this->potential = 0.0;
     

    }
};

    std::list<Particle> partList;

Particle newParticle(int size) {
    Particle* part = new Particle(boxa, boxb, boxc, sum_charges,size);
    sum_charges += part->charge;
    return *part;
}

void reassign(fcs_float *potentials, fcs_float* fields, int number, fcs_float r_cut, fcs_float offset,bool shifted) {
    fcs_int index=0;
   // printf("reassign offset: %e\n", offset);
    for (std::list<fcs_float>::iterator cutit = cutoffs.begin(); cutit != cutoffs.end(); ++cutit) {
        fcs_float rcut = *cutit;
        if(rcut==r_cut)break;
        index=index+2;
    }
    if(!shifted)++index; //first run always shifted, second unshifted.
  //  printf("\033[34;1m reassign index: %d \033[30;0m \n", index);
    fcs_int partcount = 0;
        for (std::list<Particle>::iterator it = partList.begin(); it != partList.end(); ++it) {
            Particle &part = *it;
            
            part.potential[index]=potentials[partcount];
            for(int i = 0; i<3;++i){
                part.field[index][i]=fields[3*partcount+i];
            }
            part.offset[index]=offset;
//            printf("part offset[%d]: %e\n", index,part.offset[index]);
            part.rcut[index]=r_cut;
            
            ++partcount;
        }
    
    
}

void writeResults(fcs_float *deltaPhi_shifted, fcs_float *deltaPhi, fcs_float *offset){
  //  std::string filename; filename.append("/home/gabriel/deltaPhi_");filename.append(static_cast<std::string>(CHARGE));filename.append(".dat");

char filename[100];
sprintf(filename,"/home/gabriel/deltaPhi_%f.dat", CHARGE);


printf("\nwriting results to : %s\n",filename);
    FILE *file = fopen(filename, "w");
    fprintf(file, "r_cutoff\toffset\tddeltaPhiShift\tdeltaPhi\n");
    int ind=0;
    for(std::list<fcs_float>::iterator it=++cutoffs.begin();it!=cutoffs.end();++it){
        fcs_float r_cut=*it;
 //       printf("write offset%d: %e",ind+1, offset[ind+1]);
    fprintf(file, "%f\t%e\t%e\t%e\n",r_cut,offset[ind+1],deltaPhi_shifted[ind],deltaPhi[ind]);
    ind++;
    }
    fclose(file);
}

void evaluate(){
//fcs_float deltaPhi_shifted_lowcharge[cutoffs.size()-1];
//fcs_float deltaPhi_lowcharge[cutoffs.size()-1] ;
fcs_float deltaPhi_shifted[cutoffs.size()-1] ;
fcs_float deltaPhi[cutoffs.size()-1] ;
fcs_float offset[cutoffs.size()];
offset[0]=offset[1]=0.0;
int i=2;
for(std::list<fcs_float>::iterator it=++cutoffs.begin();it!=cutoffs.end();++it){
    for(std::list<Particle>::iterator partit=partList.begin();partit!=partList.end();++partit){
        Particle part = *partit;
//        if(part.charge==CHARGE || part.charge == -CHARGE){
            //high charge
            if(part.offset[i]==0.0){
                //high charge non-shifted
                deltaPhi[i]+=abs(part.potential[i]-part.potential[1]);
            }else{
                //high charge shifted
                deltaPhi_shifted[i]+=abs(part.potential[i]-part.potential[1]);
            }
//        }else{
//            //low charge
//            if(part.offset[i]==0.0){
//                //low charge non-shifted
//                deltaPhi_lowcharge[i]+=abs(part.potential[i]-part.potential[1]);
//            }else{
//                //low charge shifted
//                deltaPhi_shifted_lowcharge[i]+=abs(part.potential[i]-part.potential[1]); 
//            }
//        }
         offset[i/2]=part.offset[i];
    //    printf(" %doffset: %f ", i,offset[i/2]);
//        printf(" %doffset: %f ", i,part.offset[i]);
    }
   // printf("\n");
            ++i;
        for(std::list<Particle>::iterator partit=partList.begin();partit!=partList.end();++partit){
        Particle part = *partit;
//        if(part.charge==CHARGE || part.charge == -CHARGE){
            //high charge
            if(part.offset[i]==0.0){
                //high charge non-shifted
                deltaPhi[i]+=abs(part.potential[i]-part.potential[1]);
            }else{
                //high charge shifted
                deltaPhi_shifted[i]+=abs(part.potential[i]-part.potential[1]);
            }
//        }else{
//            //low charge
//            if(part.offset[i]==0.0){
//                //low charge non-shifted
//                deltaPhi_lowcharge[i]+=abs(part.potential[i]-part.potential[1]);
//            }else{
//                //low charge shifted
//                deltaPhi_shifted_lowcharge[i]+=abs(part.potential[i]-part.potential[1]);  
//            }
//        }
//        offset[i]=part.offset[i];
//        printf(" %doffset: %f ", i,offset[i]);
    }
  //  printf("\n");
    //printf();
    
    deltaPhi[i] /= number/2;//Faktor 2: nur jedes zweite Teilchen hat diese Ladung.
//    deltaPhi_lowcharge[i] /= number/2;
    deltaPhi_shifted[i] /= number/2;
//    deltaPhi_shifted_lowcharge[i] /= number/2;
    ++i;
}
writeResults(deltaPhi_shifted,deltaPhi, offset);
}
void eval2(){
    Particle &part=partList.front();
    
    
    
    FILE *file = fopen("/home/gabriel/last_part.dat","w");
    fprintf(file, "rcut\toff\tPhi-Phishift\n");
    for(int i =0 ; i< cutoffs.size();++i){
   // fprintf(file,"%f\t%e\t%e\t%e\n",part.rcut[2*i],part.offset[2*i],abs(part.potential[1]-part.potential[2*i]),abs(part.potential[1]-part.potential[2*i+1]));
    fprintf(file,"%f\t%e\t%e\n",part.rcut[2*i],part.offset[2*i],abs(part.potential[2*i]-part.potential[2*i+1]));
    }
    
    //todo: calculate the difference of shited and unshifted in the same r_cut set and plot this. this is the really interesting thing. reproduction of kolafa does not seem to work right now and this way./
    fclose(file);
   // fcs_float offset;
    fcs_float deltaPhi[cutoffs.size()];
    fcs_float error[cutoffs.size()];
        
    FILE *file2 = fopen("/home/gabriel/eval2.dat","w");
    fprintf(file2, "rcut\toff\tPhi-Phishift\t(p(rc)-p(big))-(shiftedp(rc)-p(big))\n");
    for(int i =0 ; i< cutoffs.size();++i){
       // offset = part.offset[2*i];
        
        for(std::list<Particle>::iterator partIT=partList.begin();partIT!=partList.end();++partIT){
            Particle &part2 = *partIT;
            deltaPhi[i]+=abs(part2.potential[2*i]-part2.potential[2*i+1]);
            error[i]+=abs(abs(part2.potential[2*i+1]-part2.potential[0+1])-abs(part2.potential[2*i]-part2.potential[0]));
        }
        deltaPhi[i]/=number;
        error[i]/=number;
        
        fprintf(file2,"%f\t%e\t%e\t%e\n",part.rcut[2*i],part.offset[2*i],deltaPhi[i],error[i]);
    }
    
    fclose(file2);
    
    
}
int main(int argc, char** argv) {

MPI_Init(&argc, &argv);
    

    if (!(number % 2 == 0)) {
        printf("use even numbers to have a simple neutral system. increasing by one.\n");
        ++number;
    }

    /* create particles*/
    for (int i = 0; i < number; ++i) {
        partList.push_back(newParticle(partList.size()));
    }

    printf("sum of charges %f \n", sum_charges);
    
    
     for(std::list<fcs_float>::iterator it = cutoffs.begin(); it != cutoffs.end(); ++it){
        fcs_float r_cut = *it;  
   
    fcs_float fields[3 * number];
    fcs_float charges[number];
    fcs_float positions[3 * number];
    fcs_float potentials[number];
    int counter=0;
    for(std::list<Particle>::iterator partit=partList.begin();partit!=partList.end();++partit){
        Particle part = *partit;
        charges[counter]=part.charge;
     //   printf("charges: %f\n",charges[counter]);
        for(int i =0;i<3;++i){
            positions[3*counter+i]=part.position[i];
        }
        counter++;
    }
    
    

    
    FCS handle;
    fcs_int shortrangeflag = 1;
    fcs_float offset[3] = {0.0, 0.0, 0.0};
    fcs_int periodicity[3] = {1, 1, 1};

    fcs_init(&handle, "p3m", MPI_COMM_WORLD);//Solver object is created here
    fcs_float cart_boxa[3] = {static_cast<fcs_float> (bbox), 0.0, 0.0};
    fcs_float cart_boxb[3] = {0.0, static_cast<fcs_float> (bbox), 0.0};
    fcs_float cart_boxc[3] = {0.0, 0.0, static_cast<fcs_float> (bbox)};

    fcs_p3m_set_tolerance_field(handle, 100);

    fcs_set_common(handle, shortrangeflag, cart_boxa, cart_boxb, cart_boxc, offset, periodicity, number);
    fcs_p3m_set_potential_shift(handle, 1);
    fcs_p3m_set_alpha(handle,alpha);
    fcs_p3m_set_r_cut(handle,r_cut);
    fcs_p3m_set_grid(handle, 32);
    fcs_p3m_set_cao(handle, 6);
    fcs_tune(handle, number, positions, charges);
    
    fcs_run(handle, number, positions, charges, fields, potentials);
//    fcs_int *shift;fcs_p3m_get_potential_shift(handle, shift);printf("tester:shift flag: %d\n", *shift);
    
    fcs_p3m_near_parameters_t *params=new fcs_p3m_near_parameters_t();
    
    fcs_p3m_get_near_parameters(handle, params);
    
    printf("\033[31;1m alpha %f off %e \033[0m \n",params->alpha, params->potentialOffset);
    reassign(potentials, fields, number, r_cut, params->potentialOffset, true);
   
   /*unshifted run*/
    fcs_p3m_set_potential_shift(handle, 0);
    fcs_run(handle, number, positions, charges, fields, potentials);
//    fcs_p3m_get_potential_shift(handle, shift);printf("tester:shift flag: %d\n", *shift);
    fcs_p3m_get_near_parameters(handle, params);
    printf("\033[32;1m alpha %f off %e \033[0m \n",params->alpha, params->potentialOffset);
    reassign(potentials, fields, number, r_cut, params->potentialOffset, false);
    }//end for loop for cutoffs
    MPI_Finalize();
    
    evaluate();
    eval2();
    return 0;
}

